# Adivina-Numero-Errores
Ejemplo del proyecto Adivina el número en JS pero con algunos errores para corregir.
